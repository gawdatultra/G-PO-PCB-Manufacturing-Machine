<div align="center">

# G-PO — PCB Manufacturing Machine

### Interactive 3D simulator of a desktop machine that takes a blank copper board to a soldered circuit

**Drill → Paste → Place → Reflow** · CNC isolation milling · SMT assembly · AOI · Reflow soldering

![Languages](https://img.shields.io/badge/languages-AR%20%7C%20EN%20%7C%20%E4%B8%AD%E6%96%87-0c2140)
![Three.js](https://img.shields.io/badge/Three.js-r170-1f6fff?logo=threedotjs&logoColor=white)
![Single file](https://img.shields.io/badge/single%20file-HTML-e34f26?logo=html5&logoColor=white)
![CAD](https://img.shields.io/badge/CAD-Zoo%20Design%20Studio-6f42c1)
![Built with](https://img.shields.io/badge/built%20with-Claude%20Code-d97757)

**[English](#overview) · [العربية](#بالعربي) · [中文](#中文简介)**

<img src="docs/screenshots/explore-en.jpg" alt="G-PO simulator — Explore tab with the drill/mill spindle selected" width="100%">

</div>

---

## Overview

**G-PO** is a desktop PCB manufacturing machine that combines, in one enclosure, the four processes that usually need four separate machines:

| Station | Process | Key hardware |
|---|---|---|
| **1 · Drill station** | CNC isolation milling + drilling | 500 W ER11 spindle, fiducial alignment camera, dust extraction |
| **2 · Assembly station** | Solder-paste dispensing, SMT pick & place, AOI | Paste head (1.2 mm needle), vacuum nozzle with θ rotation, vision camera + LED ring light, 4 × 8 mm tape feeders |
| **3 · Reflow oven** | Reflow soldering | 4 × 300 W quartz IR heaters, K-type thermocouple, cooling fans, sliding door |

A **transfer axis** carries the board between the three stations on a single coordinate frame, so the board is never unclamped between milling and soldering.

This repository contains the **interactive simulator** of the machine: a single, self-contained web page that runs the full 3D model, the motion system, the process and the bill of materials in the browser.

## How the project was made

| Step | Tool | Output |
|---|---|---|
| **1. Mechanical design** | [Zoo Design Studio](https://zoo.dev) (CAD) | The complete machine assembly, exported as a STEP file (224 solids) |
| **2. Simulation & web app** | [Claude Code](https://www.anthropic.com/claude-code) (Anthropic) | This interactive simulator: geometry pipeline, kinematics, process logic, G-code interpreter, BOM and the AR / EN / 中文 interface |

The CAD geometry from the STEP file is quantised and embedded directly in `index.html`, so the simulator needs no external model files.

## Features

### 🔍 Explore
- All **224 parts** from the STEP file, plus **4 parts** added from the reference image (touch screen, signal tower, start/stop buttons)
- Click any part to see its name, material, dimensions, volume, estimated mass, moving axis and purchase price
- Part tree grouped into 14 sub-assemblies, with search, show/hide, isolate and focus
- View tools: preset camera angles, X-ray enclosure, section cut (length / depth / height), edge lines, unit labels, full screen

### 🧩 Disassembly
- **Exploded view** slider: every group moves along its real disassembly direction
- **20 ordered disassembly steps**, each with instructions, required tools and the parts it removes

<img src="docs/screenshots/exploded-view-en.jpg" alt="Exploded view and step-by-step disassembly" width="100%">

### ⚙️ Operation & control
- Full **10-stage automatic program** on a 100 × 150 mm LED-driver board, or run any single stage on its own
- Live machine state: E-stop, door safety interlock, pause/resume, power-on boot, signal tower and an on-machine HMI screen
- **Live readouts (DRO)** for every axis, the spindle, the oven, the doors, the vacuum and the feeders
- **Reflow profile chart** (target vs. actual) with a zone table and time-above-liquidus
- Manual jog for each head, adjustable step, station moves and equipment toggles
- **G-code terminal** with a built-in interpreter (see [G-code reference](#g-code-reference))
- Simple process physics: milled isolation channels, drilled holes, paste dots, picked/placed components, collision E-stop, component self-alignment during reflow and AOI results

<img src="docs/screenshots/reflow-run-en.jpg" alt="Automatic run during the reflow soldering stage" width="100%">

### 💰 BOM & prices
- **70 purchase items** in 11 categories, each linked to the model parts it covers
- Prices from Egyptian stores and international suppliers, with source links and notes
- Adjustable USD → EGP exchange rate, filter by price type, search, and one-click **CSV export** (Excel / Google Sheets)

### 🌐 Three languages
- **العربية (AR)** · **English (EN)** · **简体中文 (中文)**, chosen from the globe button in the top bar
- Correct direction for each language: **RTL** for Arabic, **LTR** for English and Chinese
- Everything is translated, not only the main interface: part names, materials, process stages, disassembly steps, specifications, BOM items, messages and G-code comments
- Technical terms (CNC, SMT, Reflow, G-code, AOI, HMI, SSR …) are kept in their standard form
- The chosen language is **remembered** on the next visit; a link can also force a language: `?lang=ar`, `?lang=en`, `?lang=zh`

## Process flow

```mermaid
flowchart LR
    A[1 · Load & clamp] --> B[2 · Camera alignment]
    B --> C[3 · Isolation milling]
    C --> D[4 · Drilling]
    D --> E[5 · Transfer to assembly]
    E --> F[6 · Paste dispensing]
    F --> G[7 · Pick & place]
    G --> H[8 · Optical inspection AOI]
    H --> I[9 · Reflow soldering]
    I --> J[10 · Cool & unload]
```

Reflow profile used in the simulation: preheat 150 °C → soak 180 °C → peak 245 °C → fan cooling.

## Machine at a glance

| | |
|---|---|
| Overall dimensions | 745 × 440 × 430 mm (430 mm including the signal tower) |
| Work area | 350 × 250 mm (design target) |
| Axes | 10 stepper motors — XYZ (drill), XY + 3 × Z + θ (assembly), U (transfer) |
| Positioning accuracy / repeatability | ±0.05 / ±0.02 mm (design target; T8 lead screws, MGN rails) |
| Spindle | 500 W · 48 V · ER11 (12,000 rpm in the BOM) |
| Placement | 4 × 8 mm electric tape feeders, single vacuum nozzle |
| Oven | 4 × 300 W quartz IR heaters, MAX6675 + K-type thermocouple, SSR control |
| Control | 2 × Arduino Mega 2560 + RAMPS 1.4 (TMC2209 drivers), Raspberry Pi 4 for HMI & vision, 7″ touch screen |
| Power | 220 V AC · 24 V 15 A PSU + 48 V spindle PSU |
| Estimated mass | ≈ 34 kg |
| Estimated cost | **≈ 82,181 EGP ≈ $1,481** (prices collected on 8 November 2026, at 55.5 EGP/USD, before shipping and customs) |

## Getting started

**Option 1 — open the file.** Download `index.html` and open it in a recent version of Chrome, Edge, Firefox or Safari. An internet connection is needed the first time, to load Three.js and the fonts from their CDNs.

**Option 2 — run a local server.**

```bash
git clone https://github.com/gawdatultra/G-PO-PCB-Manufacturing-Machine.git
cd G-PO-PCB-Manufacturing-Machine
python3 -m http.server 8000
# open http://localhost:8000
```

**Option 3 — publish on GitHub Pages.** In the repository go to **Settings → Pages**, set **Source** to *Deploy from a branch*, choose `main` and `/ (root)`, then save. The simulator will be published at `https://gawdatultra.github.io/G-PO-PCB-Manufacturing-Machine/`.

## Controls

| Action | Input |
|---|---|
| Orbit / pan / zoom | Left drag / right drag / scroll wheel |
| Select a part | Click it in the model or in the part list |
| Zoom onto a part | Double-click |
| Clear selection | `Esc` |
| Machine buttons | Click the E-stop, the main switch, the green/red buttons or the doors directly on the model |
| Change language | Globe button in the top bar (keyboard: ↑ ↓ Enter) |

## G-code reference

| Command | Function |
|---|---|
| `T0` `T1` `T2` `T3` | Select tool: drill bit · paste needle · pick-up nozzle · vision camera |
| `G0` / `G1 X Y Z [A] [U] [F]` | Rapid / linear move of the tool tip (mm); `A` = nozzle rotation, `U` = transfer axis, `F` = mm/min |
| `G28` | Home all axes |
| `G4 S<seconds>` | Dwell |
| `M3 S<rpm>` / `M5` | Spindle on / off |
| `M8` / `M9` | Dust extraction on / off |
| `M10` / `M11` | Nozzle vacuum on (pick) / off (release) |
| `M240` | Dispense one solder-paste dot |
| `M60 P0\|1\|2` | Move the bed to the drill station / assembly station / oven |
| `M61` / `M62` | Open / close the oven door |
| `M104 S<°C>` | Set the oven temperature |
| `M106` / `M107` | Oven fans on / off |
| `M114` | Report the current position |
| `M112` / `M999` | Emergency stop / release |
| `M24` / `M25` | Start or resume / pause the program |

## Screenshots

| Arabic (RTL) | Chinese — BOM |
|---|---|
| <img src="docs/screenshots/explore-ar.jpg" alt="Arabic interface, right-to-left" width="100%"> | <img src="docs/screenshots/bom-zh.jpg" alt="Chinese interface, bill of materials" width="100%"> |

## Technical notes

- **One file:** `index.html` (≈ 1.4 MB) contains the HTML, CSS, JavaScript, the translations and the compressed CAD geometry.
- **3D:** [Three.js](https://threejs.org) r170 as ES modules (OrbitControls, RoomEnvironment, PBR materials, soft shadows, clipping planes).
- **Geometry:** each STEP solid is stored as 16-bit quantised vertices with indexed triangles, Base64-encoded and decoded in the browser.
- **Live textures:** the PCB, the HMI screen and the reflow chart are drawn on Canvas 2D in real time.
- **Simulation:** a time-scaled motion engine (1× – 25×) with per-axis limits and speeds, a first-order oven thermal model and a job runner with stage-by-stage progress.
- **Languages:** a small built-in i18n engine applies the language before the 3D scene loads, switches `dir`/`lang` on the page and stores the choice in `localStorage`.

## Repository structure

```text
.
├── index.html              # the complete simulator (single self-contained file)
├── README.md
└── docs/
    └── screenshots/        # images used in this README
```

## Disclaimer

This is a **simulation for design review and education**. The physics are simplified, the specifications are design targets, and the prices are estimates collected in November 2026 — verify them before buying. The default profile uses Sn63/Pb37 solder paste, which contains lead: use proper ventilation and handling, or switch to a lead-free alloy such as SAC305 with an adjusted profile.

## Author

**Gawdat Muhammed** — design, engineering and development · *Qualität Lab*

The machine was designed in **Zoo Design Studio** and the simulator was built with **Claude Code**.

## Acknowledgements

- [Zoo Design Studio](https://zoo.dev) — CAD design of the machine
- [Claude Code](https://www.anthropic.com/claude-code) by Anthropic — development of the simulator
- [Three.js](https://threejs.org) — 3D rendering (MIT License)
- [IBM Plex](https://github.com/IBM/plex), [Readex Pro](https://fonts.google.com/specimen/Readex+Pro) and [Noto Sans SC](https://fonts.google.com/noto/specimen/Noto+Sans+SC) — fonts (SIL Open Font License)

## License

© 2026 Gawdat Muhammed. All rights reserved.

---

<div dir="rtl">

## بالعربي

**G-PO** ماكينة مكتبية لتصنيع الـ PCB، بتجمع في جسم واحد العمليات الأربعة اللي عادةً بتحتاج أربع ماكينات منفصلة:
**تخريم وحفر المسارات بالـ CNC ← توزيع معجون اللحام ← تركيب المكونات SMT (Pick & Place) مع فحص بصري AOI ← لحام في فرن Reflow.**
اللوحة بتتنقل بين المحطات التلاتة على محور نقل واحد، من غير ما تتفك من مكانها.

الريبو ده فيه **المحاكي التفاعلي** للماكينة: صفحة ويب واحدة بتشغّل النموذج التلاتي الأبعاد كامل وحركة المحاور ومراحل التشغيل وقائمة المكونات والأسعار.

### المشروع اتعمل إزاي
1. **التصميم الميكانيكي:** الماكينة اتصممت الأول على **Zoo Design Studio**، واتصدّرت ملف STEP فيه 224 قطعة.
2. **المحاكاة:** المحاكي التفاعلي اتعمل بـ **Claude Code**.

### المميزات
- **استكشاف:** 228 قطعة، وكل قطعة باسمها وخامتها وأبعادها وكتلتها وسعرها.
- **تفكيك:** عرض مفكّك (Exploded) و20 خطوة فك بالترتيب، مع العدة المطلوبة لكل خطوة.
- **تشغيل وتحكم:** برنامج من 10 مراحل، وزر طوارئ وحساس أمان للباب، وقراءات حية (DRO)، ومنحنى حرارة الفرن، وتحكم يدوي، وطرفية G-code.
- **المكونات والأسعار:** 70 بند من متاجر مصرية وموردين دوليين، والتكلفة التقديرية **≈ 82,181 ج.م**، مع تصدير CSV.
- **3 لغات:** عربي (من اليمين للشمال) وإنجليزي وصيني (من الشمال لليمين). الموقع بيفتكر اللغة اللي اخترتها لما تفتحه تاني.

### التشغيل
افتح `index.html` في أي متصفح حديث، ومحتاج إنترنت أول مرة عشان يحمّل Three.js والخطوط. أو فعّل **GitHub Pages** من إعدادات الريبو.

### صاحب المشروع
**Gawdat Muhammed** — التصميم والهندسة والتطوير · *Qualität Lab*

</div>

---

## 中文简介

**G-PO** 是一台桌面式 PCB 制造设备，在同一机箱内集成了通常需要四台设备才能完成的工序：**CNC 隔离铣削与钻孔 → 锡膏点胶 → SMT 元件贴装（Pick & Place）与 AOI 光学检测 → 回流焊（Reflow）**。PCB 通过一根传送轴在三个工位之间移动，全程无需重新装夹。

本仓库包含该设备的**交互式仿真器**：一个独立的网页文件，在浏览器中运行完整的 3D 模型、运动系统、工艺流程和物料清单（BOM）。

- **设计流程：** 设备先在 **Zoo Design Studio** 中完成机械设计并导出 STEP 文件（224 个实体），随后使用 **Claude Code** 开发了仿真器。
- **功能：** 零件浏览、爆炸视图与 20 步拆解、10 个阶段的自动程序、急停与门安全联锁、实时读数（DRO）、回流温度曲线、手动点动、G-code 终端、70 项物料清单（可导出 CSV）。
- **语言：** 阿拉伯语（从右到左）、英语、简体中文（从左到右），并会记住访问者选择的语言。
- **运行：** 用现代浏览器打开 `index.html` 即可（首次需联网加载 Three.js 和字体），或在仓库设置中启用 GitHub Pages。

**作者：** Gawdat Muhammed · *Qualität Lab*
